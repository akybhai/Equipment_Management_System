<!-- Main CSS-->

<link rel="stylesheet" type="text/css" href="{{ asset('css/staffAdminCss/main.css') }}">
<!-- Font-icon css-->
{{-- <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> --}}
<link rel="stylesheet" type="text/css" href="{{ asset('css/font-awesome.css') }}">
{{--  bootstrap-datepicker3 css--}}
<link rel="stylesheet" href="{{ asset('css/staffAdminCss/bootstrap-datepicker3.css') }}"/>
<style media="screen">
.vcenter {
    display: flex;
align-items: center;
justify-content: center;
flex-direction: row;
}
</style>
