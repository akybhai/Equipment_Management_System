<h1>Hey,</h1>

There is a new Request from {{$name}}.

Regards,
NUIGsocs Inventory Booking.