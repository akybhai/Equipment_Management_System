
                                    {{--<link rel="stylesheet" href="sa/css/bootstrap.css">--}}
                                    {{--<link rel="stylesheet" src="{{asset('css/bootstrap.css')}}">--}}
                                    {{--<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">--}}

                                    {{--<!-- jQuery -->--}}
                                    {{--<script src="sa/jquery/jquery.js"></script>--}}
                                    {{--<!-- Bootstrap Core JavaScript -->--}}
                                    {{--<script src="{{asset('js/bootstrap.js')}}"></script>--}}
                                    {{--<script src="sa/js/bootstrap.min.js"></script>--}}

  <div class="nav1">
    <nav class="navbar navbar-inverse navbar-static-top" style="margin: 0px">
      
    </nav>
  </div>
