(function($) {
  "use strict"; // Start of use strict

  // Vide - Video Background Settings
  $('body').vide({

    poster: "sa/img/nuig.jpg"
  }, {
    posterType: 'jpg'
  });

})(jQuery); // End of use strict
