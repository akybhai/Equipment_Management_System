<?php echo $__env->make('staffadmin.modals.editProduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('staffadmin.modals.addProduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('staffadmin.modals.singleProductView', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('meta'); ?>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<style>
#singleProductViewImg {
    display: block;
    margin: 0 auto;
}
</style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admincontent'); ?>
          <div class="app-title">
            <div>
              <h1><i class="fa fa-plus-circle"></i> Products</h1>
            </div>
            <ul class="app-breadcrumb breadcrumb">
              <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
            </ul>
          </div>
          <?php if($cat->count() != 0): ?>
          <div class="row justify-content-center">
            <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#addproductmodal"><i class="fa fa-plus-circle"></i>Add new Product</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <button class="btn btn-primary btn-lg"><i class="fa fa-download"></i>Export Inventory</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          </div>


          <br>

          <div class="row justify-content-center">

            <div class="col-md-3" align="middle">
                <div class="tile-title-w-btn">
                  <h3 class="title">Select Category</h3>
                </div>
                <div class="bs-component">
                  <div class="list-group" id="highlight1">
                    
                    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="list-group-item list-group-item-action" id="_<?php echo e($ct->id); ?>" onclick="getproduct('_<?php echo e($ct->id); ?>')" href="#" ><?php echo e($ct->category); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>

                </div>
            </div>

            <div class="col-9 table-responsive" id="productResult" >
            </div>
          <?php else: ?>
            <h2>No Categories currently in the system</h2>
            <h4>Enter New Categories</h4>
            <a class="btn btn-primary btn-lg" href="<?php echo e(route('adminstaff.newcategories')); ?>"><i class="fa fa-plus-circle"></i>Add New Category</a>&nbsp;
          <?php endif; ?>
          </div>




<!-- Style -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script type="text/javascript">

//global variable yo store selected category

//function to append the selected tag
function selectedCategory(selectCat)
{
  //loop through each category
  $("#product_category option").each(function()
  {
    //check the current category is selected
    if(selectCat === $(this).val())
    {
      $(this).prop('selected', true);
    }
  });

}





//function to pass the product ID to Edit modals
function editProductFunc(id)
{
  var route = "<?php echo e(url('products/')); ?>" + "/"+ id;

  $('#editProductForm').attr('action',route);
  $.ajax({
  type : 'get',
  url : '<?php echo e(route('adminstaff.products.edit')); ?>',
  data:{'productID':id},
  dataType:'json',
  success:function(data){
    console.log(data);
    //set the values of the edit form
    $('#productName').val(data[0].name);
    $('#productDescription').val(data[0].description);
    $('#productid').empty().html(data[0].productID);

    // check the category selected

    // $('#singleProductId').empty().html(data[0].id);
    //
    // // console.log();
    selectedCategory(data[1]);
  }
});
}


//function to view the single product view
function singleProductViewFunc(id)
{
  // ajax get call to single product
  var imgRoute = "/storage/cover_images/";
  $.ajax({
  type : 'get',
  url : '<?php echo e(route('adminstaff.products')); ?>',
  data:{'productID':id},
  dataType:'json',
  success:function(data){
    console.log(data);
    $('#singleProductId').empty().html(data[0].id);
    $('#singleProductName').empty().html(data[0].name);
    $('#singleProductDescription').empty().html(data[0].description);
    $('#singleProductViewImg').attr('src',imgRoute + data[1].cover_image);
    // console.log();
  }
  });

}



// $(".singleProductViewClass").click(function(){
//   console.log('single product View');
// });








// function to get the product
function getproduct(idval)
{
  // handle the front end highlighting
  var x= document.getElementById("highlight1");
  Array.prototype.forEach.call(x.children, i => {
      i.classList.remove("active");});
      var x= document.getElementById(idval);
      x.classList.add("active");
  // string handling
  var categorgyId = idval.split("_")[1];
  console.log(categorgyId);

  //ajax query to get product

  $.ajax({
  type : 'get',
  url : '<?php echo e(route('adminstaff.products')); ?>',
  data:{'categoryId':categorgyId},
  success:function(data){

  $('#productResult').empty().html(data);
  }
  });




};

// Script to get the products for a particular category
$('#searchBtn').click(function(){
  // get the value of the input field
  $value=$('#searchbox').val();
  //check the input field then only fire ajax call
  if($value)
  {
    $.ajax({
    type : 'get',
    url : '<?php echo e(route('localadmin.userlist')); ?>',
    data:{'search':$value},
    success:function(data){
    $('#userlistdata').empty().html(data);
    }
    });
  }
  else
  {
    // send an alert to input a value
    alert('enter the search parameter');
  }


});














//
// $.ajaxSetup({
//   headers: {
//     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//   }
// });
// // get the input values
// $productName = $('#productName').val();
// $productDescription = $('#productDescription').val();
//
// // submit the values
// $("#newProductBtn").click(function(){
//   console.log('Hello');
//   $.ajax({
//   type : 'post',
//   url : '<?php echo e(route('products.store')); ?>',
//   data:{
//     'search': 'welcome'
//   },
//   success:function(data){
//   console.log(data)
//   }
//   });
// });


function hone(idval)
{
  var x= document.getElementById("highlight1");
  Array.prototype.forEach.call(x.children, i => {
      i.classList.remove("active");});
      var x= document.getElementById(idval);
      x.classList.add("active");
};



</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('staffadmin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>