<!-- Essential javascripts for application to work-->
    <script src="<?php echo e(asset('js/staffAdminJs/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/staffAdminJs/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/staffAdminJs/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/staffAdminJs/main.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/staffAdminJs/bootstrap-datepicker.min.js')); ?>"></script>

    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo e(asset('js/staffAdminJs/plugin/pace.min.js')); ?>"></script>
    <!-- Page specific javascripts-->
    <script type="text/javascript" src="<?php echo e(asset('js/staffAdminJs/plugin/chart.js')); ?>"></script>
    <!-- Page specific javascripts-->
    <script type="text/javascript">


    </script>
