<?php if($products->count() != 0): ?>
<table class="table table-striped">
  <thead>
    <tr>
      <th>Product Id</th>
      <th>Name</th>
      <th>Description</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td style="padding:5px">
        <div class="media">
              <a href="#" class="pull-left singleProductView" onclick="singleProductViewFunc(<?php echo e($prod->id); ?>)">
                <img src="/storage/cover_images/<?php echo e($prod->ProductImages->where('product_id', $prod->productID)->first()->cover_image); ?>" class="media-photo" style="width:40px;height:40px">
              </a>
        </div>
      </td>
      <td><a href="#" data-toggle="modal" data-target="#product_view" class="singleProductView" onclick="singleProductViewFunc(<?php echo e($prod->id); ?>)"> <?php echo e($prod->name); ?></a></td>
      <td><?php echo e(str_limit($prod->description,10)); ?>...</td>
      <td>

        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#productrenamemodal" id="editProduct" onclick="editProductFunc(<?php echo e($prod->id); ?>)" ><i class="fa fa-pencil-square-o"></i>
          edit
        </button>
        <!-- Delete button -->
        <form method="POST" action="<?php echo e(url('products/'.$prod->id)); ?>" style="float:right;">
          <input type="hidden" name="_method" value="DELETE">
          <?php echo e(csrf_field()); ?>

          <button class="btn btn-danger" type="submit" value="Delete"><i class="fa fa-trash-o"></i>Delete</button>
        </form>



      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php else: ?>
  <h2> No Products for this particular category</h2>
<?php endif; ?>
