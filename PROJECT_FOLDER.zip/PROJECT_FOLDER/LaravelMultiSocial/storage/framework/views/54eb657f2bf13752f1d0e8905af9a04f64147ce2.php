<!DOCTYPE html>

<html lang="<?php echo e(app()->getLocale()); ?>">

<head>

    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">



    <!-- CSRF Token -->

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">



    <title><?php echo e(config('app.name', 'Laravel')); ?></title>



    <!-- Styles -->
    
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">
    
    <style media="screen">
        .nav1 .navbar-brand {
            height: 40px;
            padding: 5px;
            width: auto;
        }

        .nav1 .nav >li >a {
            padding-top: 15px;
            padding-bottom: 10px;

        }

    </style>
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>

<?php echo $__env->make('inc.loginheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>






    <?php echo $__env->yieldContent('content'); ?>

<!-- Scripts -->





<?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- jQuery -->

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>


</body>

</html>
