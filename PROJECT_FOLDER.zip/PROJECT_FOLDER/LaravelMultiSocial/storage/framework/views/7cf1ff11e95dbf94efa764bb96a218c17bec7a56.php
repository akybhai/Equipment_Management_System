
<div class="row">

<!-- <legend> Declined Requests </legend> -->

<div class="row">
              <table>
                <thead>
                  <tr>
                    <th style="width:100%"><legend> Declined Requests </legend> </th>
<th><a href="/zo/qo" class="btn btn-primary" style="align:Right">Export to Excel</a></th>
</tr>

</thead>
</table>
        <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Transaction ID</th>
      <th scope="col">User ID</th>
      <th scope="col">Product ID</th>
      <th scope="col">Product Name</th>
      <th scope="col">Description</th>
      <th scope="col">Start Date</th>
      <th scope="col">End Date</th>
      <th scope="col">Reason</th>


    </tr>
  </thead>
  <tbody>
    <?php if(count($articles)>0): ?>
      <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <td> <?php echo e($article->booking_id); ?></td>
      <td><?php echo e($article->user_id); ?></td>
      <td><?php echo e($article->product_id); ?></td>
      <td>welcome</td>
      <td><?php echo e($article->booking_reason); ?></td>
      <td><?php echo e($article->start_date); ?></td>
      <td><?php echo e($article->end_date); ?></td>
      <td><?php echo e($article->reject_comment); ?></td>


    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>
    </tbody>
</table>
<!-- <a href="zo/qo" class="btn btn-primary">Export to Excel</a> -->
      </div>
