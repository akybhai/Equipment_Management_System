<!-- Main CSS-->

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/staffAdminCss/main.css')); ?>">
<!-- Font-icon css-->

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/staffAdminCss/bootstrap-datepicker3.css')); ?>"/>
<style media="screen">
.vcenter {
    display: flex;
align-items: center;
justify-content: center;
flex-direction: row;
}
</style>
