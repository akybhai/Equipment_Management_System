<?php $__env->startSection('admincontent'); ?>
<style media="screen">
tr, table, td, th {

  text-align: center;
}
</style>
    <div class="app-title">
      <div>
        <h1><i class="fa fa-file-text"></i> Logs</h1>
      </div>
      <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
      </ul>
    </div>

    <div class="row justify-content-center">
      <a class="btn btn-primary btn-lg" href="download"><i class="fa fa-download"></i>Export Logs</a>
    </div><br>

    <div class="col-md-12">
      <div class="tile">
        <h3 class="tile-title">Activity logs</h3>
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th width="20%">Timestamp</th>
                <th width="80%">Activity</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td width="20%"><?php echo e($row->event_timestamp); ?></td>
                <td width="80%"><?php echo e($row->event); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('staffadmin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>