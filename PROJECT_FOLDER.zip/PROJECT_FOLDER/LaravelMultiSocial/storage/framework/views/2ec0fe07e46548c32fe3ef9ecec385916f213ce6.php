<h1>Hey,</h1>

There is a new Request from <?php echo e($name); ?>.

Regards,
NUIGsocs Inventory Booking.