<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Admin Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->yieldContent('meta'); ?>
    <?php echo $__env->make('staffadmin.static.style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navigation Top -->
    <?php echo $__env->make('staffadmin.inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Navigation Side -->
    <?php echo $__env->make('staffadmin.inc.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="app-content">
        <?php echo $__env->yieldContent('admincontent'); ?>
    </main>
    <?php echo $__env->make('staffadmin.static.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
  </body>
